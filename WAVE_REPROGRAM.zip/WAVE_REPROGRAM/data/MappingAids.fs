/*{
  "DESCRIPTION": "aids when mapping 3D fixturres",
  "CREDIT": "Jonas Fehr (jonasfehr.ch)",
  "CATEGORIES": [
    "Generator"
  ],
  "INPUTS" : [
    {
      "NAME" : "mappingImage",
      "TYPE" : "image"
    },
    {
      "NAME" : "posX",
      "TYPE" : "float",
      "DEFAULT" : 0.5,
      "LABEL" : "posX",
      "MIN" : 0.,
      "MAX" : 1
    },
    {
      "LABEL": "colorX",
      "NAME": "colorX",
      "TYPE": "color",
      "DEFAULT": [ 1.0, 0.0, 0.0, 1.0 ]
    },
    {
      "NAME" : "posY",
      "TYPE" : "float",
      "DEFAULT" : 0.5,
      "LABEL" : "posY",
      "MIN" : 0.,
      "MAX" : 1
    },
    {
      "LABEL": "colorY",
      "NAME": "colorY",
      "TYPE": "color",
      "DEFAULT": [ 0.0, 1.0, 0.0, 1.0 ]
    },
    {
      "NAME" : "posZ",
      "TYPE" : "float",
      "DEFAULT" : 0.5,
      "LABEL" : "posZ",
      "MIN" : 0.,
      "MAX" : 1
    },
    {
      "LABEL": "colorZ",
      "NAME": "colorZ",
      "TYPE": "color",
      "DEFAULT": [ 0.0, 0.0, 1.0, 1.0 ]
    },
    {
      "NAME" : "automate",
      "TYPE" : "bool",
      "DEFAULT" : false,
      "LABEL" : "automate"
    },
    {
      "NAME" : "speed",
      "TYPE" : "float",
      "DEFAULT" : 0.1,
      "LABEL" : "speed",
      "MIN" : 0.0,
      "MAX" : 1.
    },
    {
      "NAME" : "lineWidth",
      "TYPE" : "int",
      "DEFAULT" : 1,
      "LABEL" : "lineWidth",
      "MIN" : 1,
      "MAX" : 20
    },
    {
      "NAME" : "showIndex",
      "TYPE" : "bool",
      "DEFAULT" : false,
      "LABEL" : "showIndex"
    },
    {
      "NAME" : "colOffsetFag",
      "TYPE" : "float",
      "DEFAULT" : 0.1,
      "LABEL" : "colOffsetFag",
      "MIN" : 0.0,
      "MAX" : 1.
    },
    {
      "NAME" : "colOffsetHylder",
      "TYPE" : "float",
      "DEFAULT" : 0.16666,
      "LABEL" : "colOffsetHylder",
      "MIN" : 0.0,
      "MAX" : 1.
    }
  ]
}*/

mat4 rotationMatrix(vec3 axis, float angle)
{
    axis = normalize(axis);
    float s = sin(angle);
    float c = cos(angle);
    float oc = 1.0 - c;

    return mat4(oc * axis.x * axis.x + c,           oc * axis.x * axis.y - axis.z * s,  oc * axis.z * axis.x + axis.y * s,  0.0,
                oc * axis.x * axis.y + axis.z * s,  oc * axis.y * axis.y + c,           oc * axis.y * axis.z - axis.x * s,  0.0,
                oc * axis.z * axis.x - axis.y * s,  oc * axis.y * axis.z + axis.x * s,  oc * axis.z * axis.z + c,           0.0,
                0.0,                                0.0,                                0.0,                                1.0);
}

mat4 build_transform(vec3 pos, vec3 ang)
{
  float cosX = cos(ang.x);
  float sinX = sin(ang.x);
  float cosY = cos(ang.y);
  float sinY = sin(ang.y);
  float cosZ = cos(ang.z);
  float sinZ = sin(ang.z);

  mat4 m;

  float m00 = cosY * cosZ + sinX * sinY * sinZ;
  float m01 = cosY * sinZ - sinX * sinY * cosZ;
  float m02 = cosX * sinY;
  float m03 = 0.0;

  float m04 = -cosX * sinZ;
  float m05 = cosX * cosZ;
  float m06 = sinX;
  float m07 = 0.0;

  float m08 = sinX * cosY * sinZ - sinY * cosZ;
  float m09 = -sinY * sinZ - sinX * cosY * cosZ;
  float m10 = cosX * cosY;
  float m11 = 0.0;

  float m12 = pos.x;
  float m13 = pos.y;
  float m14 = pos.z;
  float m15 = 1.0;

  /*
  //------ Orientation ---------------------------------
  m[0] = vec4(m00, m01, m02, m03); // first column.
  m[1] = vec4(m04, m05, m06, m07); // second column.
  m[2] = vec4(m08, m09, m10, m11); // third column.

  //------ Position ------------------------------------
  m[3] = vec4(m12, m13, m14, m15); // fourth column.
  */

  //------ Orientation ---------------------------------
  m[0][0] = m00; // first entry of the first column.
  m[0][1] = m01; // second entry of the first column.
  m[0][2] = m02;
  m[0][3] = m03;

  m[1][0] = m04; // first entry of the second column.
  m[1][1] = m05; // second entry of the second column.
  m[1][2] = m06;
  m[1][3] = m07;

  m[2][0] = m08; // first entry of the third column.
  m[2][1] = m09; // second entry of the third column.
  m[2][2] = m10;
  m[2][3] = m11;

  //------ Position ------------------------------------
  m[3][0] = m12; // first entry of the fourth column.
  m[3][1] = m13; // second entry of the fourth column.
  m[3][2] = m14;
  m[3][3] = m15;

  return m;
}

mat3 rotateX(float rad) {
    float c = cos(rad);
    float s = sin(rad);
    return mat3(
        1.0, 0.0, 0.0,
        0.0, c, s,
        0.0, -s, c
    );
}
mat3 rotateY(float rad) {
    float c = cos(rad);
    float s = sin(rad);
    return mat3(
        c, 0.0, -s,
        0.0, 1.0, 0.0,
        s, 0.0, c
    );
}
mat3 rotateZ(float rad) {
    float c = cos(rad);
    float s = sin(rad);
    return mat3(
        c, s, 0.0,
        -s, c, 0.0,
        0.0, 0.0, 1.0
    );
}

// book of shader matrixes https://thebookofshaders.com/08/
mat2 scale(vec2 _scale){
    return mat2(_scale.x,0.0,
                0.0,_scale.y);
}

mat2 rotate2d(float _angle){
    return mat2(cos(_angle),-sin(_angle),
                sin(_angle),cos(_angle));
}

vec3 hsv2rgb(vec3 c) {
  vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
  vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
  return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main(  ){
    vec2 st = gl_FragCoord.xy / RENDERSIZE.xy;
    vec4 p = IMG_PIXEL(mappingImage, gl_FragCoord.xy);
    float alpha = 1.;
    if(p.w == (0.0)) {
      alpha = 0.;
    }


    vec3 pos = vec3(0.);
    if(automate){
      pos.z =  1.-distance(mod(TIME*speed, 1.),p.z);
      pos.y =  1.-distance(mod(TIME*speed, 1.),p.y);
      pos.x =  1.-distance(mod(TIME*speed, 1.),p.x);
    } else {
      pos.z =  1.-distance(posZ,p.z);
      pos.y =  1.-distance(posY,p.y);
      pos.x =  1.-distance(posX,p.x);
    }
    float lW = lineWidth/max(RENDERSIZE.x, RENDERSIZE.y);
    pos = smoothstep(1.-lW, 1., pos);

    vec3 finalColor = vec3(colorX*pos.x+colorY*pos.y+colorZ*pos.z);
    gl_FragColor = vec4( finalColor, alpha);





    if(showIndex){

      int index = int(p.w*255);

      int fag = index & 0x0F;
      int hylde = (index & 0xF0 ) >> 4;

      vec3 hsv;

      hsv.x = mod(float(fag)*colOffsetFag+ float(hylde)*colOffsetHylder, 1.);
      hsv.y = 1.;
      hsv.z = 1.;



      gl_FragColor = vec4( hsv2rgb(hsv), alpha);
    }

}
